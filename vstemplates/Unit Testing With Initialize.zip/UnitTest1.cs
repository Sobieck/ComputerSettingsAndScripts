﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$
{
    [TestClass]
    public class $safeitemname$
    {

        [TestInitialize]
        public void Initialize()
        {
            
        }

        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
