﻿module BohFoundation {
    export interface I {
        
    }

    export class Implementation implements I {
        
        static $inject = [];

        constructor() {
            
        }

    }
    
} 

module BohFoundation.Main {
    Register.Applicant.service("",)
}