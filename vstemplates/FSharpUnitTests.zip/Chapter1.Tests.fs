﻿namespace ProjectEuler.Problem1.Tests

open Microsoft.VisualStudio.TestTools.UnitTesting

module Problem1Tests = 
  
    [<TestClass>]
    type Problem1() = 

        [<TestInitialize>]
        member x.initialize() =
            ignore

        [<TestMethod>]
        member x.yourTestName() =
            Assert.AreEqual(1,2)