﻿module BohFoundation {
    describe("", () => {
        var apiEndpoint = "";
        var typeOfData = "";
        var service, authRepo, errorResponse, successResponse, genericResolver;

        beforeEach(() => {
            successResponse = new Common.Models.ServerResponseModel(null, true);
            errorResponse = new Common.Models.ServerResponseModel(null, false);

            var commonStubs = new TestHelpers.CommonStubs();

            authRepo = commonStubs.createAuthRepo();
            genericResolver = commonStubs.createGenericResolver();
            
        });

        

    });
} 